from donation_pkg.homepage import show_homepage, donate, show_donations
from donation_pkg.user import login, register


database = {"admin": "password123"}
donations = []
authorized_user = ""

# call homepage function
show_homepage()

# checking if authorized user is empty
if authorized_user == "":
    print("You must be logged in to donate.")
else:
    # check if command exists in database
    print("Logged in as:"  + authorized_user)

def choose_option():
    global database, authorized_user
    while  True:
        option = input("Choose an option(1. Login, 2. Register, 3. Donate, 4. Show Donations , 5. Exit): ")
        if int(option) == 1:
            print("Please enter your login details: ")
            username = input("Username: ")
            password = input("Password: ")
            authorized_user = login(database, username,  password)
            if authorized_user:
                print("Successfully Logged In!")
        elif option == '2':
            print("Please enter your registeraton details")
            username = input('Username: ')
            password = input('Password: ')
            authorized_user =  register(database, username)
            if not authorized_user:
                database[username] = password
        elif option == '3':
            if authorized_user == "":
                print("Please log in first.")
            else:
                donation_string = donate(authorized_user)
                donations.append(donation_string)
            
        elif option == '4':
            show_donations(donations)
            
        elif option == '5':
            print("Goodbye! Thank you  for using our application.")
        else:
            print("Invalid Option. Please try again.")


choose_option()