def login(database, username, password):
    if username in database:
        if database[username] == password:
            print("Welcome Back!", username)
            return username
        else:
            print("Incorrect Password for", username)
            return ""
    else:
        print("User not found. Please register.")
        return ""

def register(database, username):
    username = username.lower() # Make sure the username is lowercase to avoid duplicates
    if username in database:
        print("Username already exists")
        return""
    else:
        database[username] = ""
        print("Registration Successful")
        return username